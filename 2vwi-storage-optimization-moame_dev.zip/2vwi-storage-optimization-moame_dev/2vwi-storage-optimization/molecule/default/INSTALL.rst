***********************************
VMware driver installation guide
***********************************

Install
========

.. code-block:: bash

   $ pip install molecule-vmware
